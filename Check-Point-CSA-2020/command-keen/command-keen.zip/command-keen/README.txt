﻿Welcome to the land of CSA!

In this challenge you'll help our CSA hero KEEN to find the lost secret :)
Your first mission is to find the secret sentence - spread in the game levels.
To complete the mission you'll use the attached game code,
and game recordings that would guide you to the secret sentence.

Each recording file stores information of KEEN's movements in the game,
according to the following format:

2Bytes - movement counter 
2Bytes - 2 buttons click - for throwing/jumping as in the game controller settings
2Bytes - x direction of movement
2Bytes - y direction of movement
.
.

In order to find out what is the secret sentence you should be able to play 
the recordings in the game BY THEIR ORDER, BUT! only once you are DONE with ALL the game levels.

IMPORTANT 1: each recording you should play from the start of the game.

IMPORTANT 2: submit the flag with the following format CSA{...}.

HINT: use the "hint"s in the code.



GOOD LUCK!
	    ________________
          .'   \  \    \  \ `.
        /       \  \    \  \  '. 
       /\        |  |    |  |   \
      |  \       |  |    |  |    \
      |  /      _|__|____|__|__   \
      | /     /                \  | 
      |/      | <(=)>    <(=)> '  |
      |       |         _|     |  |
      | (|)   |  /\            |  |
      '       ' |  \____      /  ]
        '     '\ \_____/    .|  '
         '__,'  \_________.' |_/ 
                |____________\  ,.
              ,.              /\  \ 
            .`                ||   \
          .`                  ----\ \               
         /                    <== |, \         
        /                     <== | \_\
       '                      ---/     |      
       `._     /|                \____/         
       /  `-,./ |                 '
      /     /   |                 |        
     (______`'._|_________________|       By Geoff Sims © 1998 