import os
import string
from subprocess import run,Popen, PIPE, STDOUT
import time

def main():
    charlist = b'0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    flag = b""
    child_proccess = Popen("Pass_it_on.exe", stdout=PIPE, stdin=PIPE)
    done =False
    round_num=0
    l=0
    while not done:
        if l%27 == 0:
            l=0
            flag = b""
        averages = []
        for j,ch in enumerate(charlist):
            if done:
                break
            time_diffs = []
            for i in range(10):
                please_enter = child_proccess.stdout.readline()
                if l % 26 == 0 or l%27 == 0 or l%25==0:
                    if b'Please enter your password to log in' not in please_enter:
                        print(please_enter)
                        break
                before = time.time()
                child_proccess.stdin.write(flag+charlist[j:j+1]+b'\n')
                child_proccess.stdin.flush()
                res = child_proccess.stdout.readline()
                if l > 25:
                    if b'enter' not in please_enter:
                        print(please_enter)
                        done = True
                        break
                after = time.time()
                diff = after-before
                time_diffs.append(diff)
            average = sum(time_diffs) / len(time_diffs)
            averages.append(average)


        k = averages.index(max(averages))
        next_char = charlist[k:k+1]
        flag = flag + next_char
        print(flag ,len(flag))
        l+=1

    res = child_proccess.stdout.readline()
    print(res)
    child_proccess.stdin.write(flag + b'\n')

    # child_proccess.stdin.write(b"CSA{" + flag +b"}" + b'\r\n')
    child_proccess.stdin.flush()
    res = child_proccess.stdout.readline()
    print(res)
    child_proccess.terminate()

    print(flag)


if __name__ == "__main__":
    main()